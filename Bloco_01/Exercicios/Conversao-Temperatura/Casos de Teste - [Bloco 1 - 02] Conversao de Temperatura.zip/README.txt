Arquivo zip gerado em: 11/12/2021 16:06:08 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 1 - 02] Conversão de Temperatura