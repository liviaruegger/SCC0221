Arquivo zip gerado em: 10/12/2021 23:00:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 1 - 07] Multiplicação de Matrizes